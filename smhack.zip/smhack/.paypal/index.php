<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
  *{
    margin: 0;
    outline: none;
    padding: 0;
    box-sizing: border-box;
  }
  body{
    height: 100vh;
    display: flex;
    align-items: center;
    justify-content: center;
    font-family: Arial, Sans-Serif;
  }
  .aa{
    border: solid 5px #395de02c;
  }
  .logo-container{
    max-width: 75px;
    max-height: 75px;
    margin: 0 auto;
  }
  .logo-container img{
    width: 100%;
    height: 100%;
  }
  .login-container{
    height: 600px;
    width: 400px;
    background-color: #ffff;
    text-align: center !important;
    margin: 0.3cm;
  }
  .input-container{
    border: solid 1px #d1c8c8;
    text-align: left;
    margin-top: 0.8cm;
    border-radius: 3px;
    position: relative;
    transition: .3s;
  }
  input{
    width: 100%;
    border: 0px;
    background: transparent;
    height: 45px;
    padding-left: 0.2cm;
    font-size: 14px;
    border: solid 1px #d1c8c8;
    text-align: left;
    margin-top: 0.8cm;
    border-radius: 3px;
    position: relative;
    transition: .3s;
  }
  label{
    text-align: left;
  }
  .link{
    padding-top: 0.3cm;
    padding-bottom: 0.3cm;
    text-align: left;
  }
  .link a{
    color: #5674df;
    font-weight: bold;
    text-decoration: none;
  }
  button{
    width: 100%;
    height: 45px;
    color: #fff;
    font-weight: bold;
    border-radius: 55px;
    background-color: #5674df;
    margin-top: 0.3cm;
    margin-bottom: 0.3cm;
    text-transform: capitalize;
    font-size: 14px;
    border: solid 1px #395de0;
    cursor: pointer;
  }
  button:hover{
    color: #fff;
    background: #395de0;
    border: solid 1px #395de0;
  }
  .hr{
  display: flex;
  align-items: center;
  color: #4b4f56;
  justify-content: center;
}
  hr{
  width: 40%;
  margin: 1em;
  border: solid 1px #ccd0d5;
}
.off{
  border: solid 1px #222;
  color: #222;
  background-color: #fff;
}
.rodape{
  padding: 0.5cm;
  color: #eceaea;
}
input:hover{
  border: solid 3px #395de0;
  box-shadow: 0px 3px 50px #395de02c;
}
.error{
  text-transform: uppercase;
  font-weight: 200;
  color: #fa3e3e;
}
  </style>
</head>
<body>
  <div class="login-container">
    <div class="logo-container">
    <img src="logo.png">
  </div>
  <?php if(isset($_SESSION["error"])): ?>
    <div class="error">
      algo deu errado. tente novamente!
    </div>
  <?php unset($_SESSION["error"]);
  endif;
  ?>
    <form action="login.php" method="POST">
        <input type="text" placeholder="E-mail ou número de celular" name="username">
      <br>
        <input type="password" placeholder="Sua senha" name="password">
      <p class="link">
        <a href="#">Esqueceu sua senha?</a>
      </p>
      <button type="submit">
        próximo
      </button>
    </form>
      <div class="hr">
        <hr>ou<hr>
      </div>
      <button class="off">
        inscrever-se
      </button>
    <footer class="rodape">
      @paypal - 2024
    </footer>
  </div>
</body>
</html>