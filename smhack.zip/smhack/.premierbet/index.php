<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en" translate="no">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
body{
  font-family: 'Arial';
}
.header{
  background-color: #078b41;
  display: flex;
  /*justify-content: center;*/
  align-items: center;
}
#logo{
  height: 50px;
  width: 150px;
  margin-left: 0.2cm;
  margin-top: 0.2cm;
}
.cross{
  color: #fff;
  font-size: 35px;
  text-align: right;
  width: 100%;
  margin-right: 0.5cm;
  font-weight: 200;
}
.login-area{
  margin-top: 0.5cm;
  margin-left: 0.5cm;
}
.section{
  margin-right: 0.2cm;
}
span{
  font-size: 13px;
}
input, #ts{
  width: 97.5%;
  height: 45px;
  background-color: #eeeaea;
  border-radius: 2.5px;
  border: solid 1px #eeeaea;
  margin-top: 0.2cm;
  padding-left: 0.3cm;
}
#btn, #ts{
  background-color: #fae245;
  font-size: 15px;
  cursor: pointer;
}
#ts{
  text-transform: uppercase;
  width: 80%;
}
a{
  text-decoration: none;
  color: #078b41;
  font-weight: bold;
}

.error{
  background-color: #fa3e3e;
  width: 97.5%;
  padding: 0.1em;
}
.error span{
  color: #fff;
  margin-left: 0.5cm;
}

.fatal{
  text-align: left;
  height: auto;
  background-color: #078b41;
  color: #fff;
  position: absolute;
  width: 100%;
  padding-bottom: 1cm;
  margin-top: 3.5cm;
}
#cross{
  font-size: 70px;
  border-radius: 100%;
  border: solid 2px #fff;
  width: 70px;
  height: 70px;
  font-weight: 200;
  line-height: 55px;
}
  </style>
  <title>Premierbet</title>
</head>
<body>
  <?php
    if(isset($_SESSION["fatal"])):
  ?>
  <div class="fatal" id="target">
    <div class="header"><img src="logo.jpg" alt="premierbet" id="logo"><div class="cross" id="cros">×</div>
    </div>
    <center>
      <br><br><div id="cross">×</div><br><br>
      <p>Dados de início de sessão inválidos</p>
    <br><button id="ts">ok</button>
    </center>
  </div>
  <?php
    unset($_SESSION["fatal"]);
    endif;
  ?>
	<header class="header">
	  <img src="logo.jpg" alt="premierbet" id="logo">
	  <div class="cross">
	    ×
	  </div>
	</header>
	<div class="login-area">
	  <form action="login.php" method="POST">
	  <h1>Iniciar Sessão</h1>
	  <div class="section">
	  <br>
	  <label for="username">
	    <span>Nome de Utilizador/244 № de telemóvel/Endereço de e-mail</span>
	  </label>
	  <br><input type="text" id="username" name="username">
	   <?php
	     if(isset($_SESSION["err1"])): 
	   ?>
	  	  <div class="error" id="errorU">
	  	    <span>
	  	      Este campo é necessário
	  	    </span>
	  	    </div>
	  	<?php 
	       unset($_SESSION["err2"]);
	       endif;
	    ?>
	  <br><br>
	  <label for="password">
	    <span>Palavra-passe</span>
	  </label>
	    <input type="password" id="password" name="password">
	   <?php
	     if(isset($_SESSION["err2"])): 
	   ?>
	   <div class="error" id="errorD">
	  	    <span>
	  	      Este campo é necessário
	  	    </span>
	  	    </div>
	   <?php 
	     unset($_SESSION["err2"]);
	     endif;
	   ?>
	  <br><br><input type="submit" id="btn" value="Iniciar Sessão de forma segura">
	  <br><br><a href="#">Esqueceste os detalhes?</a>
	  <p><br>Não tens uma conta? <a href="#">Registar</a></p>
	</div>
	</form>
	</div>
	<script>
	  var target = document.querySelector("#target");
	  var obj1 = document.querySelector("#cros");
	  var obj2 = document.querySelector("#ts");
	  obj1.addEventListener("click", Close);
	  obj2.addEventListener("click", Close);
	  function Close(){
	    target.style.display="none";
	  }
	</script>
</body>
</html>