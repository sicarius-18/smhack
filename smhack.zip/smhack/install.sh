#!/usr/bin/env bash

#------------------------------------------#
# Script de instalação de dependências
#------------------------------------------#

# Função para verificar a presença do PHP
check_php() {
    if command -v php &> /dev/null; then
        echo -e "\033[0;32mPHP já está instalado.\033[0m"
    else
        echo -e "\033[1;33mPHP não encontrado. Iniciando a instalação...\033[0m"
        install_php
    fi
}

# Função para instalar o PHP em sistemas Linux
install_php_linux() {
    sudo apt update
    sudo apt install -y php
}

# Função para instalar o PHP no Termux
install_php_termux() {
    pkg update
    pkg install -y php
}

# Função para verificar a presença do ngrok
check_ngrok() {
    if command -v ngrok &> /dev/null; then
        echo -e "\033[0;32mNgrok já está instalado.\033[0m"
    else
        echo -e "\033[1;33mNgrok não encontrado. Iniciando a instalação...\033[0m"
        install_ngrok
    fi
}

# Função para instalar o ngrok em sistemas Linux
install_ngrok_linux() {
    wget -q -O ngrok.zip https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-stable-linux-amd64.zip
    unzip ngrok.zip
    sudo mv ngrok /usr/local/bin/
    rm ngrok.zip
}

# Função para instalar o ngrok no Termux
install_ngrok_termux() {
    wget -q -O ngrok.zip https://bin.equinox.io/c/bNyj1mQVY4c/ngrok-stable-linux-arm64.zip
    unzip ngrok.zip
    mv ngrok $PREFIX/bin/
    rm ngrok.zip
}

# Função para detectar o ambiente (Linux ou Termux) e instalar o PHP
install_php() {
    if [[ "$(uname -o)" == "Android" ]]; then
        install_php_termux
    else
        install_php_linux
    fi
}

# Função para detectar o ambiente (Linux ou Termux) e instalar o ngrok
install_ngrok() {
    if [[ "$(uname -o)" == "Android" ]]; then
        install_ngrok_termux
    else
        install_ngrok_linux
    fi
}

# Função principal de execução
main() {
    echo -e "\033[1;34mIniciando o processo de instalação...\033[0m"
    check_php
    check_ngrok
    echo -e "\033[0;32mInstalação concluída!\033[0m"
}

# Executar a função principal
main
