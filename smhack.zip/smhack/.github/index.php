<?php
  session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    *{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  outline: none;
}
body{
  font-family: 'Arial';
  background-color: #0f1317;
}
.header{
  padding-top: 60px;
  text-align: center;
}
.header img{
  height: 60px;
  width: 60px;
  border-radius: 100px;
}
.header h2,h3{
  font-weight: 200;
  color: #fff;
  margin: 0.3cm;
}
.form{
  height: auto;
  width: 300px;
  background-color: #01111b;
  margin-top: 0.2cm;
  border-radius: 5px;
  border: solid 1px #373737;
  color: #fff;
  padding: 0.5cm;
  font-size: 13px;
}
input{
  width: 90%;
  height: 25px;
  border: solid 1px #373737;
  background-color: #010515;
  border-radius: 5px;
  color: #fff;
  padding-left: 0.2cm;
  transition: .1s;
}
input:hover{
  border: solid 3px #4277ba;
}
.controls{
  display: flex;
  justify-content: center;
  align-items: center;
  max-width: 90%;
  margin-top: 0.2cm;
}
.controls label{
  text-align: left;
  flex: 35%;
}
.controls #tt{
  text-align: right;
}
a{
  color: #4277ba;
  text-decoration: none;
}

#btn{
  background: #42772a;
  cursor: pointer;
  height: 30px;
}
#btn:hover{
  border: 0px;
}

#ff{
  background: #0d131a;
}

h3{
  color: #fa3e3e;
}
  </style>
  <title>Github</title>
</head>
<body>
  <header class="header">
    <img src="logo.png" alt="Github">
    <h2>Entrar no Github</h2>
<?php
  if(isset($_SESSION["error"])):
?>
    <div class="error">
      <h3>Algo deu errado!</h3>
    </div>
<?php
  unset($_SESSION["error"]);
  endif;
?>
  </header>
  <center>
    <div class="form">
<form action="login.php" method="POST">
      <label for="username">
        <span>Nome de usuário ou endereço de e-mail</span>
      </label>
      <br><br><input type="text" name="username" id="username">
      <div class="controls">
   <label for="password">
        <span>Senha</span>
      </label>
   <span id="tt"><a href="#">Esqueceu sua senha?</a></span>
      </div>
<br><input type="password" name="password" id="password">
<br><br><input type="submit" value="Entrar" id="btn">
    </div>
    <div class="form" id="ff">
      <a href="#"><b>Entre com uma senha</b></a>
      <p><br>Novo no github? <a href="#">Crie uma conta</a></p>
      </form>
    </div>
  </center>
</body>
</html>